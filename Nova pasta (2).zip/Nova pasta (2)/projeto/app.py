from flask import Flask, render_template, request, redirect, url_for
from database import Session, criar_banco
from models import User, Book

app = Flask(__name__)

criar_banco()

@app.route("/")
def index():
    with Session() as session:
        usuarios = session.query(User).all()
        livros = session.query(Book).all()

        return render_template(
            "index.html",
            usuarios=usuarios,
            livros=livros
        )

@app.route("/usuario/novo", methods=["GET", "POST"])
def novo_usuario():
    if request.method == "POST":
        nome = request.form["nome"]
        email = request.form["email"]

        with Session() as session:
            usuario = User(nome=nome, email=email)
            session.add(usuario)
            session.commit()

        return redirect(url_for("index"))

    return render_template("user_form.html")

@app.route("/livro/novo", methods=["GET", "POST"])
def novo_livro():
    if request.method == "POST":
        titulo = request.form["titulo"]
        user_id = int(request.form["user_id"])

        with Session() as session:
            livro = Book(titulo=titulo, user_id=user_id)
            session.add(livro)
            session.commit()

        return redirect(url_for("index"))

    with Session() as session:
        usuarios = session.query(User).all()

        return render_template("book_form.html", usuarios=usuarios)

if __name__ == "__main__":
    app.run(debug=True)